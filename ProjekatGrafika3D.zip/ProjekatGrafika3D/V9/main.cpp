﻿// main.cpp
// Autor: Luka Vranjesevic RA 131/2021
// Opis: Skulptorski park – 4 rotirajuce skulpture (kocke i piramide), kamera se pomera WSAD, rotacija kamere EQ, pauza za figure - Space, P/O za projekciju.

#define _CRT_SECURE_NO_WARNINGS


#include <iostream>
#include <fstream>
#include <sstream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <chrono>
#include <thread>


#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

unsigned int compileShader(GLenum type, const char* path);
unsigned int createShader(const char* vsPath, const char* fsPath);
void processInput(GLFWwindow* window);


// Scena postavke
bool        usePerspective = true;
bool        rotationPaused = false;
glm::vec3 cameraPos = glm::vec3(0.0f, 1.0f, 10.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, 0.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

float       cameraTurnAngle = -90.0f;
bool spacePressedLastFrame = false;


int main() {
    // Init GLFW
    if (!glfwInit()) return -1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    unsigned int wWidth = 800;
    unsigned int wHeight = 800;
    GLFWwindow* window = glfwCreateWindow(wWidth, wHeight, "Skulptorski park", NULL, NULL);
    if (!window) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(window);

    // Init GLEW
    if (glewInit() != GLEW_OK) { glfwTerminate(); return -1; }

    int textureWidth, textureHeight, textureChannels;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load("indeks.png", &textureWidth, &textureHeight, &textureChannels, STBI_rgb_alpha);

    GLuint indexTexture;
    glGenTextures(1, &indexTexture);
    glBindTexture(GL_TEXTURE_2D, indexTexture);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, textureWidth, textureHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(image);

    float indexVerts[] = {
        450.0f, 750.0f,  0.0f, 0.0f,  // dole levo
        790.0f, 750.0f,  1.0f, 0.0f,  // dole desno
        790.0f, 790.0f,  1.0f, 1.0f,  // gore desno
        450.0f, 790.0f,  0.0f, 1.0f   // gore levo
    };
    unsigned int indexIndices[] = { 0, 1, 2, 2, 3, 0 };

    GLuint indexVAO, indexVBO, indexEBO;
    glGenVertexArrays(1, &indexVAO);
    glGenBuffers(1, &indexVBO);
    glGenBuffers(1, &indexEBO);
    glBindVertexArray(indexVAO);
    glBindBuffer(GL_ARRAY_BUFFER, indexVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(indexVerts), indexVerts, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexEBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indexIndices), indexIndices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    // Ucitavanje shadera
    unsigned int shader = createShader("basic.vert", "basic.frag");
    int locM = glGetUniformLocation(shader, "uM");
    int locV = glGetUniformLocation(shader, "uV");
    int locP = glGetUniformLocation(shader, "uP");

    unsigned int textureShader = createShader("texture.vert", "texture.frag");
    int img_uP = glGetUniformLocation(textureShader, "uP");

    glm::mat4 projectionP = glm::perspective(glm::radians(90.0f), (float)wWidth / (float)wHeight, 0.1f, 100.0f); //Matrica perspektivne projekcije (FOV, Aspect Ratio, prednja ravan, zadnja ravan)
    glm::mat4 projectionO = glm::ortho(-4.0f, 4.0f, -4.0f, 4.0f, 0.1f, 100.0f); //Matrica ortogonalne projekcije (Leva, desna, donja, gornja, prednja i zadnja ravan)



    // Zemlja
    float planeV[] = {
    -5,-0.5, 5, 0.2,0.8,0.2,1,
     5,-0.5, 5, 0.2,0.8,0.2,1,
    -5,-0.5,-5, 0.2,0.8,0.2,1,
     5,-0.5, 5, 0.2,0.8,0.2,1,
     5,-0.5,-5, 0.2,0.8,0.2,1,
    -5,-0.5,-5, 0.2,0.8,0.2,1
    };

    unsigned int planeVAO, planeVBO;
    glGenVertexArrays(1, &planeVAO);
    glGenBuffers(1, &planeVBO);
    glBindVertexArray(planeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, planeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(planeV), planeV, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    float cubeV[] = {
        // Prednja
        -0.5f,-0.5f, 0.5f, 0.3,0.3,0,1,
         0.5f,-0.5f, 0.5f, 0.3,0.3,0,1,
         0.5f, 0.5f, 0.5f, 0.3,0.3,0,1,
        -0.5f,-0.5f, 0.5f, 0.3,0.3,0,1,
         0.5f, 0.5f, 0.5f, 0.3,0.3,0,1,
        -0.5f, 0.5f, 0.5f, 0.3,0.3,0,1,

        // Zadnja
        -0.5f,-0.5f,-0.5f, 0,1,0,1,
        -0.5f, 0.5f,-0.5f, 0,1,0,1,
         0.5f, 0.5f,-0.5f, 0,1,0,1,
        -0.5f,-0.5f,-0.5f, 0,1,0,1,
         0.5f, 0.5f,-0.5f, 0,1,0,1,
         0.5f,-0.5f,-0.5f, 0,1,0,1,

         // Leva
         -0.5f, 0.5f, 0.5f, 0,0,1,1,
         -0.5f, 0.5f,-0.5f, 0,0,1,1,
         -0.5f,-0.5f,-0.5f, 0,0,1,1,
         -0.5f, 0.5f, 0.5f, 0,0,1,1,
         -0.5f,-0.5f,-0.5f, 0,0,1,1,
         -0.5f,-0.5f, 0.5f, 0,0,1,1,

         // Desna
          0.5f, 0.5f, 0.5f, 1,1,0,1,
          0.5f,-0.5f, 0.5f, 1,1,0,1,
          0.5f,-0.5f,-0.5f, 1,1,0,1,
          0.5f, 0.5f, 0.5f, 1,1,0,1,
          0.5f,-0.5f,-0.5f, 1,1,0,1,
          0.5f, 0.5f,-0.5f, 1,1,0,1,

          // Gornja
          -0.5f, 0.5f,-0.5f, 1,0,1,1,
          -0.5f, 0.5f, 0.5f, 1,0,1,1,
           0.5f, 0.5f, 0.5f, 1,0,1,1,
          -0.5f, 0.5f,-0.5f, 1,0,1,1,
           0.5f, 0.5f, 0.5f, 1,0,1,1,
           0.5f, 0.5f,-0.5f, 1,0,1,1,

           // Donja
           -0.5f,-0.5f,-0.5f, 0,1,1,1,
            0.5f,-0.5f,-0.5f, 0,1,1,1,
            0.5f,-0.5f, 0.5f, 0,1,1,1,
           -0.5f,-0.5f,-0.5f, 0,1,1,1,
            0.5f,-0.5f, 0.5f, 0,1,1,1,
           -0.5f,-0.5f, 0.5f, 0,1,1,1
    };

    unsigned int cubeVAO, cubeVBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glBindVertexArray(cubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeV), cubeV, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // Piramida
    float pyrV[] = {
        // baza
        -0.5f,0.0f,-0.5f, 1,1,1,1,
         0.5f,0.0f,-0.5f, 1,1,1,1,
         0.5f,0.0f, 0.5f, 1,1,1,1,
        -0.5f,0.0f,-0.5f, 1,1,1,1,
         0.5f,0.0f, 0.5f, 1,1,1,1,
        -0.5f,0.0f, 0.5f, 1,1,1,1,
        // prednja strana
        -0.5f,0.0f, 0.5f, 1,0,0,1,
         0.5f,0.0f, 0.5f, 1,0,0,1,
         0.0f,1.0f, 0.0f, 1,0,0,1,
         // desna strana
          0.5f,0.0f, 0.5f, 0,1,0,1,
          0.5f,0.0f,-0.5f, 0,1,0,1,
          0.0f,1.0f, 0.0f, 0,1,0,1,
          // zadnja strana
           0.5f,0.0f,-0.5f, 0,0,1,1,
          -0.5f,0.0f,-0.5f, 0,0,1,1,
           0.0f,1.0f, 0.0f, 0,0,1,1,
           // leva strana
           -0.5f,0.0f,-0.5f, 1,1,0,1,
           -0.5f,0.0f, 0.5f, 1,1,0,1,
            0.0f,1.0f, 0.0f, 1,1,0,1

    };
    unsigned int pyrVAO, pyrVBO;
    glGenVertexArrays(1, &pyrVAO);
    glGenBuffers(1, &pyrVBO);
    glBindVertexArray(pyrVAO);
    glBindBuffer(GL_ARRAY_BUFFER, pyrVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(pyrV), pyrV, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 7 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glm::vec3 sculptPos[4] = { {-3,0,0},{-1,0,0},{1,0,0},{3,0,0} };

    glClearColor(1, 1, 1, 1);

    const double FPS = 60.0;
    const double frameDuration = 1000.0 / FPS; // trajanje frejma u milisekundama
    float angle = 0;

    while (!glfwWindowShouldClose(window)) {
        auto frameStart = std::chrono::high_resolution_clock::now();

        processInput(window);

        // view
        {
            glm::vec3 fr;
            fr.x = cos(glm::radians(cameraTurnAngle));
            fr.y = 0.0f;
            fr.z = sin(glm::radians(cameraTurnAngle));
            cameraFront = glm::normalize(fr);
        }
        glm::mat4 view = glm::lookAt(
            cameraPos, cameraPos + cameraFront, cameraUp
        );
		glUseProgram(shader);

        if (!rotationPaused) angle += 0.8f;

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUniformMatrix4fv(locV, 1, GL_FALSE, glm::value_ptr(view));
        usePerspective ? glUniformMatrix4fv(locP, 1, GL_FALSE, glm::value_ptr(projectionP))
            : glUniformMatrix4fv(locP, 1, GL_FALSE, glm::value_ptr(projectionO));

        glm::mat4 m(1.0f);
        //  Crtanje zemlje
        glUniformMatrix4fv(locM, 1, GL_FALSE, glm::value_ptr(m));
        glBindVertexArray(planeVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Crtanje skulputra
        for (int i = 0; i < 4; i++) {
            glm::mat4 s(1.0f);
            glm::mat4 base = s
                * glm::translate(glm::mat4(1.0f), sculptPos[i])
                * glm::rotate(glm::mat4(1.0f), glm::radians(angle), glm::vec3(0, 1, 0));
            // Kocka
            glUniformMatrix4fv(locM, 1, GL_FALSE, glm::value_ptr(base));
            glBindVertexArray(cubeVAO);
            glDrawArrays(GL_TRIANGLES, 0, 36);
            // Piramida
            glm::mat4 top = base * glm::translate(glm::mat4(1.0f), glm::vec3(0, 0.5f, 0));
            glUniformMatrix4fv(locM, 1, GL_FALSE, glm::value_ptr(top));
            glBindVertexArray(pyrVAO);
            glDrawArrays(GL_TRIANGLES, 0, 18);
        }
        glUseProgram(textureShader);
        glm::mat4 ortho = glm::ortho(0.0f, (float)wWidth, 0.0f, (float)wHeight);
        glUniformMatrix4fv(img_uP, 1, GL_FALSE, &ortho[0][0]);

        glBindTexture(GL_TEXTURE_2D, indexTexture);
        glBindVertexArray(indexVAO);
        glDisable(GL_DEPTH_TEST);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

        glEnable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

        glfwSwapBuffers(window);
        glfwPollEvents();

        auto frameEnd = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double, std::milli>(frameEnd - frameStart).count();

        if (elapsed < frameDuration) {
            std::this_thread::sleep_for(std::chrono::milliseconds((long long)(frameDuration - elapsed)));
        }
    }

    // Ciscenje
    glDeleteBuffers(1, &planeVBO);
    glDeleteVertexArrays(1, &planeVAO);
    glDeleteBuffers(1, &cubeVBO);
    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteBuffers(1, &pyrVBO);
    glDeleteVertexArrays(1, &pyrVAO);
    glDeleteBuffers(1, &indexEBO);
    glDeleteBuffers(1, &indexVBO);
	glDeleteVertexArrays(1, &indexVAO);
    glDeleteProgram(shader);
    glDeleteProgram(textureShader);

    glfwTerminate();
    return 0;
}


unsigned int compileShader(GLenum type, const char* source)
{
    std::string content = "";
    std::ifstream file(source);
    std::stringstream ss;
    if (file.is_open())
    {
        ss << file.rdbuf();
        file.close();
        std::cout << "Uspesno procitao fajl sa putanje \"" << source << "\"!" << std::endl;
    }
    else {
        ss << "";
        std::cout << "Greska pri citanju fajla sa putanje \"" << source << "\"!" << std::endl;
    }
    std::string temp = ss.str();
    const char* sourceCode = temp.c_str();

    int shader = glCreateShader(type);

    int success;
    char infoLog[512];
    glShaderSource(shader, 1, &sourceCode, NULL);
    glCompileShader(shader);

    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        if (type == GL_VERTEX_SHADER)
            printf("VERTEX");
        else if (type == GL_FRAGMENT_SHADER)
            printf("FRAGMENT");
        printf(" sejder ima gresku! Greska: \n");
        printf(infoLog);
    }
    return shader;
}
unsigned int createShader(const char* vsSource, const char* fsSource)
{
    unsigned int program;
    unsigned int vertexShader;
    unsigned int fragmentShader;

    program = glCreateProgram();

    vertexShader = compileShader(GL_VERTEX_SHADER, vsSource);
    fragmentShader = compileShader(GL_FRAGMENT_SHADER, fsSource);

    glAttachShader(program, vertexShader);
    glAttachShader(program, fragmentShader);

    glLinkProgram(program);
    glValidateProgram(program);

    int success;
    char infoLog[512];
    glGetProgramiv(program, GL_VALIDATE_STATUS, &success);
    if (success == GL_FALSE)
    {
        glGetShaderInfoLog(program, 512, NULL, infoLog);
        std::cout << "Objedinjeni sejder ima gresku! Greska: \n";
        std::cout << infoLog << std::endl;
    }

    glDetachShader(program, vertexShader);
    glDeleteShader(vertexShader);
    glDetachShader(program, fragmentShader);
    glDeleteShader(fragmentShader);

    return program;
}

void processInput(GLFWwindow* window) {
    float speed = 0.2f;
    float cameraTurnSpeed = 2.0f;

    glm::vec3 r = glm::normalize(glm::cross(cameraFront, cameraUp));
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) cameraPos += speed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) cameraPos -= speed * cameraFront;
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) cameraPos -= r * speed;
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) cameraPos += r * speed;

    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) cameraTurnAngle += cameraTurnSpeed;
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) cameraTurnAngle -= cameraTurnSpeed;

    bool spacePressedNow = glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS;
    if (spacePressedNow && !spacePressedLastFrame) {
        rotationPaused = !rotationPaused;
    }
    spacePressedLastFrame = spacePressedNow;

    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) usePerspective = true;
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) usePerspective = false;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(window, true);
}
